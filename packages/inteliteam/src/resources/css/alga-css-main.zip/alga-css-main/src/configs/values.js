module.exports = {
  between: 'spaceBetween',
  around: 'spaceAround',
  evenly: 'spaceEvenly'
}
