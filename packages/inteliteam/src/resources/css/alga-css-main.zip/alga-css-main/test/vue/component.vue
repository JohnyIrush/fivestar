<template>
  <div :class="['display-flex', 'justifyContent-center', 'navBar', 'mt-3.75rem', 'width-2/3', 'gap-10px']">
    <div :class="{'pt-2px': true}">
      Test
    </div>
    <span class="borderTop-none w-33.333333pct">
      Border
    </span>
  </div>
</template>
