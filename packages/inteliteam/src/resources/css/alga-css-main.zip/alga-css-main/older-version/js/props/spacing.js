module.exports = {
  mg: 'margin',
  pd: 'padding'
}
