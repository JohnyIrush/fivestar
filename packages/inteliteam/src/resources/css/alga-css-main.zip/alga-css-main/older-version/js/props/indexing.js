module.exports = {
  zi: 'z-index',
  order: 'order',
  tab: 'tab-size',
  opacity: 'opacity',
  lh: 'line-height'
}
