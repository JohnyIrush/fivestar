module.exports = {
  template: {
    cols: 'grid-template-columns',
    rows: 'grid-template-rows',
  },
  span: {
    col: 'grid-column',
    row: 'grid-row'
  }
}
