module.exports = ['inherit', 'initial', 'revert', 'unset']
