module.exports = {
  focus: 'focus',
  hover: 'hover',
  active: 'active',
  disabled: 'disabled',
  visited: 'visited',
  checked: 'checked'
}
