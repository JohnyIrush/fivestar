module.exports = {
  wd: 'width',
  hg: 'height',
  mwd: 'max-width',
  nwd: 'min-width',
  mhg: 'max-height',
  nhg: 'min-height'
}
