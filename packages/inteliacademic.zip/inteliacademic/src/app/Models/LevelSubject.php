<?php

namespace Softwarescares\Inteliacademic\app\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class LevelSubject extends Pivot
{
    //
}
